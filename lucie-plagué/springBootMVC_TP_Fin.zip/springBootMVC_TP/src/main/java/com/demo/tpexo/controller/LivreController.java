package com.demo.tpexo.controller;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.demo.tpexo.entity.Livre;

@Controller
public class LivreController {

	// Choix d'un éditeur dans une liste
	private Map<String, String> editeurListe = new LinkedHashMap<String, String>() {
		{
			put("editions Hachette", "Hachette");
			put("editions Editis", "Editis");
			put("editions Gallimard", "Gallimard");
			put("editions Albin Michel", "Albin Michel");
			put("editions Actes Sud", "Actes Sud");
		}
	};

	// Choix d'un type d'edition en bouton-radio (un seul choix possible)
	private Map<String, String> editionOption = new LinkedHashMap<String, String>() {
		{
			put("poche", "Poche");
			put("normal", "Normale");
		}
	};

	// Mapping de l'url
	@GetMapping({ "/afficheLivreForm" })
	public String afficheForm(Model model) {
		model.addAttribute("livre", new Livre());
		model.addAttribute("listeDesEditeurs", editeurListe);
		model.addAttribute("editionOption", editionOption);
		return "livre-form";
	}

	// exécution de la requete
	@RequestMapping("/traitementForm")
	public String traitementForm(@ModelAttribute("livre") Livre unLivre) {

		return "livre-confirmation";
	}
}
