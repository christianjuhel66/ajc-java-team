package com.demo.entities;

public interface Decoupage {

	public String decoupageMateriel();
}
