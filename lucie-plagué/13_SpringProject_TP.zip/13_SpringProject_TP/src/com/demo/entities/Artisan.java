package com.demo.entities;

public interface Artisan {

	public String redigerDevis();
	
	public String decoupage();

}
