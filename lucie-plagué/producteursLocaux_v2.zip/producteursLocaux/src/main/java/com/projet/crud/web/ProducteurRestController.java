package com.projet.crud.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.projet.crud.Entity.Producteur;
import com.projet.crud.metier.ProducteurServiceInterface;

@RestController
@RequestMapping("/api")
public class ProducteurRestController {

	// Injection de l'interface métier de Producteur
	@Autowired
	private ProducteurServiceInterface producteurService;

	/*
	 * // Contructeur
	 * 
	 * @Autowired public ProducteurRestController(ProducteurServiceInterface
	 * producteurService) { this.producteurService = producteurService; }
	 */

	/*
	 * // Setter
	 * 
	 * @Autowired public void setProducteurService(ProducteurServiceInterface
	 * producteurService) { this.producteurService = producteurService; }
	 */

	// Mapping pour tester l'URL
	@GetMapping("/premiertest")
	public String premierTest() {
		return "Je fonctionne correctement";
	}

	// End-point pour récupérer la liste des producteurs en fonction de son id
	@GetMapping("/producteurs")
	public List<Producteur> getProducteurs() {
		System.out.println("Passage dans la méthode findAll() de DaoProducteurImpl");
		return producteurService.findAll();
	}

	/*
	 * @GetMapping("/appelFindAll") public List<Producteur> findAll() {
	 * System.out.println("Passage dans la méthode findAll()"); return
	 * producteurService.findAll(); }
	 */

	// End-point pour récupérer 1 producteur en fonction de son id
	@GetMapping("/producteur/{id}")
	public Producteur findById(@PathVariable(name = "id") Long producteurId) {
		System.out.println("Je passe par findById endpoint pour retourner un élément recherché par son id");
		if (producteurId < 0) {
			// throw new ProducteurNotFoundException("Producteur id non trouvé - " +
			// producteurId);
		}
		return producteurService.findById(producteurId);
	}

	/*
	 * @GetMapping("/create") public Producteur create() {
	 * System.out.println("Je passe par create endpoint, pour créer un producteur");
	 * Producteur prod = new Producteur("Tintin", "numero affiché",
	 * "Auteuil-Le-Roi", "farine", true); producteurService.save(prod); return prod;
	 * }
	 */

	// Définir un EndPoint "/producteur" qui sauvegarde un nouveau producteur
	@PostMapping("/producteur")
	public Producteur addProducteur(@RequestBody Producteur producteurNew) {
		System.out.println("Je passe par create endpoint, pour créer un producteur");
		Long idGenere = producteurService.save(producteurNew);
		producteurNew.setId(idGenere);
		return producteurNew;
	}

	/*
	 * @GetMapping("/update") public Producteur update() { System.out.
	 * println("passage par update endpoint pour mettre à jour dans la db");
	 * Producteur prod = producteurService.findById(2L); prod.setNom("inconnu");
	 * prod.setProduit("produit modifié"); producteurService.save(prod); return
	 * prod; }
	 */

	// Définir un EndPoint "/producteur" qui modifie un producteur
	@PutMapping("/producteur/{id}")
	public Producteur updateProducteur(@PathVariable(name = "id") Long producteurId,
			@RequestBody Producteur producteur) {
		System.out.println("passage par update endpoint pour mettre à jour dans la db");
		// Vérifier que l'id recherché est conforme au nombre d'employes
		if (producteurId < 0) {
			// throw new EmployeNotFoundException("Employé id non trouvé - " +
			// producteurId);
		}
		/*
		 * Producteur prod = producteurService.findById(producteurId);
		 * prod.setNom(producteur.getNom()); prod.setProduit(producteur.getProduit());
		 * producteurService.save(prod); return prod;
		 */
		return producteurService.updateProducteur(producteurId, producteur);
	}

	/*
	 * @GetMapping("/delete") public void delete() { System.out.
	 * println("passage par delete endpoint pour supprimer un élément de la db");
	 * 
	 * producteurService.deleteById(3L); }
	 */

	// Supprimer un producteur en fonction de son id
	@DeleteMapping("/producteur/{id}")
	public void deleteProducteurId(@PathVariable(name = "id") Long producteurId) {
		System.out.println("passage par delete endpoint pour supprimer un élément de la db");

		producteurService.deleteById(producteurId);
	}
}
