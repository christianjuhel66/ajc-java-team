package com.projet.crud.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.projet.crud.Entity.Producteur;

@Repository // injection de la classe dans le repo pour utilisation
@Primary // Priorité d'utilisation de la classe
public class DaoProducteurImpl_JPA implements DaoInterface {

	// Injection de la classe EntityManager
	@Autowired
	private EntityManager em;

	// Affiche tous les producteurs
	@Override
	@Transactional
	public List<Producteur> findAll() {
		TypedQuery<Producteur> typedQuery = em.createQuery("from Producteur", Producteur.class);
		return typedQuery.getResultList();
	}

	// Affiche 1 producteur en fonction de son id
	@Override
	@Transactional
	public Producteur findById(Long id) {
		return em.find(Producteur.class, id);
	}

	// Création d'un producteur
	@Override
	@Transactional
	public Long save(Producteur producteur) {
		Producteur storedProducteur = em.merge(producteur);
		return storedProducteur.getId();
	}

	// Modification d'un producteur
	@Override
	@Transactional
	public Producteur updateProducteur(Long idProducteur, Producteur producteurModify) {
		Query query = em.createQuery("update Producteur as p set p.nom = :nom, p.produit = :produit where p.id = :id");
		query.setParameter("id", idProducteur);
		query.setParameter("nom", producteurModify.getNom());
		query.setParameter("produit", producteurModify.getProduit());
		query.executeUpdate();

		return findById(idProducteur);
	}

	// Suppression d'un producteur
	@Override
	@Transactional
	public void deleteById(Long id) {
		Query query = em.createQuery("delete from Producteur where id=:producteurId");
		query.setParameter("producteurId", id);
		query.executeUpdate();

	}

}
