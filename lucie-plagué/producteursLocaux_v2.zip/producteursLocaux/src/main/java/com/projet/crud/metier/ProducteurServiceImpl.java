package com.projet.crud.metier;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.projet.crud.Entity.Producteur;
import com.projet.crud.dao.DaoInterface;

@Service
public class ProducteurServiceImpl implements ProducteurServiceInterface {

	// Injection de l'interface Dao
	@Autowired
	private DaoInterface dao;

	// Affiche tous les producteurs
	@Override
	@Transactional
	public List<Producteur> findAll() {
		return dao.findAll();
	}

	// Affiche 1 producteur en fonction de son id
	@Override
	@Transactional
	public Producteur findById(Long id) {
		return dao.findById(id);
	}

	// Création d'un producteur
	@Override
	@Transactional
	public Long save(Producteur producteur) {
		return dao.save(producteur);
	}

	// Mise un jour d'un producteur
	@Override
	@Transactional
	public Producteur updateProducteur(Long idModify, Producteur producteurModify) {
		return dao.updateProducteur(idModify, producteurModify);
	}

	// Suppression d'un producteur
	@Override
	@Transactional
	public void deleteById(Long id) {
		dao.deleteById(id);
	}

}
