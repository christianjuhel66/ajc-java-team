package com.projet.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProducteursLocauxApplicationTests {

	@Test
	void contextLoads() {
	}

}
