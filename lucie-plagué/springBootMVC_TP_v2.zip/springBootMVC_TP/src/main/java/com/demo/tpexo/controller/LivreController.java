package com.demo.tpexo.controller;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.demo.tpexo.entity.Livre;

@Controller
public class LivreController {

	private Map<String, String> editeurListe = new LinkedHashMap<String, String>() {
		{
			put("Ha", "Hachette");
			put("Ed", "Editis");
			put("Ga", "Gallimard");
			put("AM", "Albin Michel");
			put("AS", "Actes Sud");
		}
	};

	@GetMapping({ "/afficheLivreForm" })
	public String afficheForm(Model model) {
		model.addAttribute("livre", new Livre());
		model.addAttribute("listeDesEditeurs", editeurListe);
		return "livre-form";
	}

	@RequestMapping("/traitementForm")
	public String traitementForm(@ModelAttribute("livre") Livre unLivre) {

		return "livre-confirmation";
	}
}
