package com.github.inposa.mini_projet_restaurant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiniProjetRestaurantApplicationTests {

	@Test
	void contextLoads() {
	}

}
