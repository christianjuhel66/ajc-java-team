package com.github.inposa.mini_projet_restaurant;

public class Test {
    public static void main(String[] args) {

    }
}
