package com.github.inposa.mini_projet_restaurant.entities;

public interface I_Restaurant {

}
