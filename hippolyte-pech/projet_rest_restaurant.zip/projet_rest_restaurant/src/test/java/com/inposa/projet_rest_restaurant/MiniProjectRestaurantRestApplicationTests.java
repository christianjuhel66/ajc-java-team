package com.inposa.projet_rest_restaurant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiniProjectRestaurantRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
