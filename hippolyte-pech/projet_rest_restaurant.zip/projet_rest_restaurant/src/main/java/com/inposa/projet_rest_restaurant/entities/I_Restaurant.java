package com.inposa.projet_rest_restaurant.entities;

public interface I_Restaurant {

}
