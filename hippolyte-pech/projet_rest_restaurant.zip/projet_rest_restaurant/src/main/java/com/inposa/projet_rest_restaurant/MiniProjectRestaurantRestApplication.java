package com.inposa.projet_rest_restaurant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiniProjectRestaurantRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(MiniProjectRestaurantRestApplication.class, args);
	}

}
