package com.github.singleton.entites;

public interface Fruit {
    public void sePresenter();
}
