package com.ajc.TPJavaWeb.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ajc.TPJavaWeb.entities.Livre;

@Controller
public class LiveController {
	
	@RequestMapping("/afficheLivreForm")
	public String afficheLivreForm() {
		return "livre-forme";
	}
	
	@RequestMapping("/traitementForm")
	public String traiteLivreForm(HttpServletRequest request, Model model) {
		String titre = request.getParameter("livreNom");
        String auteur = request.getParameter("livreAuteur");
        String editeur = request.getParameter("livreEditeur");
        int prix = Integer.parseInt(request.getParameter("livrePrix"));
        Livre l = new Livre(titre, auteur, prix, editeur);
        
		return "livre-confirmation";
	}

}
