package com.ajc.TPJavaWeb.entities;

public class Livre {
	private String titre;
	private String auteur;
	private int prix;
	private String editeur; 
	
	public String getEditeur() {
		return editeur;
	}

	public void setEditeur(String editeur) {
		this.editeur = editeur;
	}

	public Livre(String titre, String auteur, int prix, String editeur) {
		this.prix = prix;
		this.auteur = auteur;
		this.titre = titre;
		this.editeur = editeur;
	}

	public String getAuteur() {
		return auteur;
	}

	public void setAuteur(String auteur) {
		this.auteur = auteur;
	}

	public int getPrix() {
		return prix;
	}

	public void setPrix(int prix) {
		this.prix = prix;
	}

	public String getTitre() {
		return titre;
	}

	public void setTitre(String titre) {
		this.titre = titre;
	}
	
	

}
