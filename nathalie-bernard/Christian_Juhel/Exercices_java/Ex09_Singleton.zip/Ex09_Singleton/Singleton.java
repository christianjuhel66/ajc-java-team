package com.singleton;

public enum Singleton {

	APP;

	private int test;

	public int getTest() {
		return test;
	}

	public void setTest(int test) {
		this.test = test;
	}

}
