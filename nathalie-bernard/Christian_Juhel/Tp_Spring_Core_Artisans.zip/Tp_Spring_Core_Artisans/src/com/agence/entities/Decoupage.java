package com.agence.entities;

public interface Decoupage {

	public String decoupageDeMateriaux();
}
