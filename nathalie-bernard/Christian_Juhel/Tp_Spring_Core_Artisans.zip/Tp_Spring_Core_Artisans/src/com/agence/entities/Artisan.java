package com.agence.entities;

public interface Artisan {

	public void faireUnDevis();
	public String getDecoupage();
}
