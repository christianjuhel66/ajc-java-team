package com.librairie.livres;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LivresApplication {

	public static void main(String[] args) {
		SpringApplication.run(LivresApplication.class, args);
	}

}
