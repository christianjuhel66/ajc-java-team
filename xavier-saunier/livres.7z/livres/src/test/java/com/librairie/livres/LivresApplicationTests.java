package com.librairie.livres;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LivresApplicationTests {

	@Test
	void contextLoads() {
	}

}
