package com.example.producteur;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProducteurApplicationTests {

	@Test
	void contextLoads() {
	}

}
